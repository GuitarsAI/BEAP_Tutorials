/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*  basic_delay.h                                                            */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   Header file to generate a Basic Delay Effect.                           */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Renato Profeta, Guitars.AI                                    */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   05th April 2020. Created by Richard Sikora from                         */
/*                                                                           */
/*****************************************************************************/

#ifndef BASIC_DELAY_H_
#define BASIC_DELAY_H_

void clear_delay_buffer(void);
signed int seconds_to_samples(double seconds, unsigned short sampling_rate);
signed int delayline(signed int x, unsigned short delay_samples, unsigned short sampling_rate);
signed int basic_delay_effect(signed int x, double dry_mix, double wet_mix, double feedback, double delay_seconds, unsigned short sampling_rate);

#endif /* BASIC_DELAY_H_ */

/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*  basic_delay.c                                                              */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5505 USB Stick. Basic Delay Effect up to 0.5 seconds.            */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Renato Profeta, Guitars.AI                                    */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   05th April 2020. Created by Richard Sikora from                         */
/*                                                                           */
/*****************************************************************************/

#define MAX_BUFFER_LENGTH 12000

signed int delay_buffer[MAX_BUFFER_LENGTH]; // Buffer for a maximum delay of MAX_BUFFER_LENGTH samples.

/*****************************************************************************/
/* clear_buffer    ()                                                        */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Fill buffer used for delay  with zeroes to prevent                        */
/*                                                                           */
/*****************************************************************************/

void clear_delay_buffer(void)
{
 int i;

 for ( i = 0 ; i < MAX_BUFFER_LENGTH ; i++)
  {
	 delay_buffer[i] = 0;
  }
}

signed int seconds_to_samples(double seconds, unsigned short sampling_rate)
{
	unsigned short samples = MAX_BUFFER_LENGTH;
	if (seconds > 0.5)
	{
		samples = MAX_BUFFER_LENGTH;
	}
	else
	{
		samples = seconds * sampling_rate;
	}
	return samples;
}

signed int delayline(signed int x, double delay_seconds, unsigned short sampling_rate)
{
	static unsigned short index = 0;
	signed int y = delay_buffer[index];
	delay_buffer[index++] = x;
	index %= seconds_to_samples(delay_seconds, sampling_rate);
	return y;
}

signed int basic_delay_effect(signed int x, double dry_mix, double wet_mix, double feedback, double delay_seconds, unsigned short sampling_rate)
{
	static signed int before_delay = 0;
	static signed int after_delay = 0;

	before_delay = x + after_delay*feedback;
	after_delay = delayline(before_delay, delay_seconds,sampling_rate);
	return after_delay*wet_mix + x*dry_mix;
}
